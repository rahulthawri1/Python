
#int
a = int(1)   # a will be 1
b = int(2.4) # b will be 2
c = int("3") # c will be 3
print ("a:", a, "b:", b, "c:", c)


#floats
d = float(1)     # d will be 1.0
e = float(2.4)   # e will be 2.4
f = float("3")   # f will be 3.0
g = float("6.2") # g will be 6.2
print ("d:", d, "e:", e, "f:", f, "g:", g)

#strings
strA = str("s1") # strA will be 's1'
strB = str(2)    # strB will be '2'
strC = str(3.0)  # strC will be '3.0'
print ("strA:", strA, "strB:" ,strB, "strC:",strC)
