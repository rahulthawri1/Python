word = input("Enter your word:")
for letter in word:
    if letter == "a":
        continue
    elif letter == "e":
        continue
    elif letter == "i":
        continue
    elif letter == "o":
        continue
    elif letter == "u":
        continue
    else:
        print(letter)