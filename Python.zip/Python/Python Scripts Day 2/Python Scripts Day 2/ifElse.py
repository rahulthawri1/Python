'''
if true_or_false_condition:
    perform_if_condition_true
else:
    perform_if_condition_false
'''

# calculate and print output
inputAmt = float(input("Enter the input value: "))
if inputAmt < 85528:
    output = inputAmt * 0.18 - 556.02
    print("Output is less than 85528")
else:
	output = (inputAmt - 85528) * 0.32 + 14839.02
if output < 0.0:
	output = 0.0
output = round(output,0)
print("The output is:", output)

# reformatted above program with if written on the same line
inputAmt = float(input("Enter the input amount: "))
if inputAmt < 85528: output = inputAmt * 0.18 - 556.02
else: output = (inputAmt - 85528) * 0.32 + 14839.02
if output < 0.0: output = 0.0

output = round(output,0)
print("The output is:", output)


# calculate and print output with else if
inputAmt = float(input("Enter the input amount: "))
if inputAmt < 85528:
	output = inputAmt * 0.18 - 556.02
elif inputAmt >= 85528 and inputAmt < 200000:
	output = (inputAmt -85528) * 0.52 + 14839.02
else:
	output = (inputAmt - 85528) * 0.32 + 14839.02
if output < 0.0:
	output = 0.0
output = round(output,0)
print("The output is:", output)
