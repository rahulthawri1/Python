# while else
i = 1
while i < 5:
    print(i)
    i+=1
else:
    print("else: ", i)

# for else
for i in range(1, 5):
    print(i)
else:
    print("else: ", i)

# while else with break, notice that else block is not executed if we break from the loop.
count = 0
while count < 5:
   print(count, " is  less than 5")
   count = count + 1
   break;
else:
    print(count, " is not less than 5")