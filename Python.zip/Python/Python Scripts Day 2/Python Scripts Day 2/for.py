# for loop using range()
for i in range(10):
    print("Value of i is now:", i)
    pass

for i in range(2, 8):
    print("Value of i is now:", i)
    pass

for i in range(2, 8, 3):
    print("Value of i is now:", i)
    pass

for i in range(1,1):
    print("Value of i is now:", i)
    pass

# using for loop to iterate a list
lang = ["Java", "C", "Python"]
for i in lang:
    if i == "Python":
        print("I love Python")

for i in "Python":
    print(i)
