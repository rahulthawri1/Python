
a = 1
b = 10
print("a") if a > b else print("b")


a = 10
b = 10
print("a") if a > b else print("=") if a == b else print("b")
