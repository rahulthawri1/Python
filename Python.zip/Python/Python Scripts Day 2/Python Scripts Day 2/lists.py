langlist = ["Python", "Java", "C", "Corba", "Javascript", "Ruby", "Groovy"]
print(langlist)

#print(langlist[1])

#print(langlist[-1])

#print(langlist[2:5])

#print(langlist[:4])

#print(langlist[2:])

#print(langlist[-4:-1])

#langlist[1] = "Angular"
#print(langlist)

#for x in langlist:
#   print(x)

#langlist.append("React")
#print(langlist)

#Insert an item as the second position:
#langlist.insert(1, "Scala")
#print(langlist)

#langlist.remove("Java")
#print(langlist)

#The pop() method removes the specified index, (or the last item if index is not specified):
#langlist.pop()
#print(langlist)

#The del keyword removes the specified index and can also delete the list completely
#del langlist[0]
#print(langlist)

#langlist.clear()
#print(langlist)

#newlist = langlist.copy()
#print(newlist)

#copylist = list(langlist)
#print(copylist)

#This can also be achieved with extend() and append()
#list2 = ["React", "Angular"]
#list3 = langlist + list2
#print(list3)

#constructor
#newlist = list(("Angular", "React"))
#print(newlist)
