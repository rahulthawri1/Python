word = input("Enter your word:")
for letter in word:
    if letter == "a":
        break
    elif letter == "e":
        break
    elif letter == "i":
        break
    elif letter == "o":
        break
    elif letter == "u":
        break
    else:
        print(letter)