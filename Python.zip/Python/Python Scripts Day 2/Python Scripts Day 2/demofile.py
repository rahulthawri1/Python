for i, j in zip(range(10), range(9, -1, -1)):
    print("i:", i, "j:", j)



