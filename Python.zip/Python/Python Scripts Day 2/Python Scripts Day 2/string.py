# examples of some string functions
a = "Hello"
b = "Python"
print(a)
print(a+b)

b = '''Hello,
Python'''
print(b)


c = "Hello, Python!"
print(c[1])
print(c[2:5])
print(c[-5:-2])
print(len(c))
print(c.lower())
print(c.upper())
print(c.replace("H", "J"))
print(c.split(",")) # returns ['Hello', ' World!']


age = 48
txt = "My name is John, and I am {}"
print(txt.format(age))

d = " Hello, Python"
print(d.strip())